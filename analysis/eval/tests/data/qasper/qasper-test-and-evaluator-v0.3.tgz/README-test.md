A sample made for tests.
